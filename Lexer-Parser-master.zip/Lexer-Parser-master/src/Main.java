import compile.MainComplier;

import java.io.*;

public class Main {
    public static void main(String[] args)throws IOException {
        new MainComplier(); //对象的引用
    }
}
